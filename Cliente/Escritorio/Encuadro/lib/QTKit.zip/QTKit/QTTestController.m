/*****************************************************************************************************************************************************
|	QTTestController.m
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
|	associated documentation files (the "Software"), to deal in the Software without restriction,
|	including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
|	 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do
|	so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
|	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
|	FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
|	WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
****************************************************************************************************************************************************/

#import "QTTestController.h"
#import "QTKitView.h"
#import "QTKitTranscode.h"

@implementation QTCompressController

- (IBAction)doAbout:(id)sender
{
    [aboutWindow makeKeyAndOrderFront:sender];
}


- (IBAction)doCompress:(id)sender
{
    [movieView compress];
}

- (IBAction)doNew:(id)sender
{
}

- (IBAction)doOpen:(id)sender
{
	[movieView openSourceURL];
        [movieView setWindowSizeForMovie];
        [openItem setEnabled:NO];
        [closeItem setEnabled:YES];
        [saveItem setEnabled:YES];
        [saveAsItem setEnabled:YES];
        [compressItem setEnabled:YES];
}

- (IBAction)doSave:(id)sender
{
}

- (IBAction)doSaveAs:(id)sender
{
}

- (void)awakeFromNib
{
    [fileMenu setAutoenablesItems:NO];
    [testMenu setAutoenablesItems:NO];
    [closeItem setEnabled:NO];
    [saveItem setEnabled:NO];
    [saveAsItem setEnabled:NO];
    [compressItem setEnabled:NO];
}

- (void)windowWillClose:(NSNotification *)notif
{
    [openItem setEnabled:YES];
    [movieView stop:self];
    [closeItem setEnabled:NO];
    [saveItem setEnabled:NO];
    [saveAsItem setEnabled:NO];
    [compressItem setEnabled:NO];
}

- (NSPanel *)progressPanel
{
    return progressPanel;
}

- (NSProgressIndicator *)progressBar
{
    return progressBar;
}

- (NSPanel *)exportPanel
{
    return exportPanel;
}

- (NSPopUpButton *)exportMenu
{
    return exportMenu;
}

- (IBAction)pickExport:(id)sender
{
    [movieView setExport];
}

@end
