/*************************************************************************
|	QTKitFrameData.h
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
**************************************************************************/

/*************************************************************************
|	A simple class for passing data about a movie
**************************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import <Foundation/Foundation.h>
#import "QTKitView.h"


@interface FrameData : NSObject {
TimeValue origMovieTime;
GDHandle savedDevice;
CGrafPtr savedPort;
short refNum;
Movie dstMovie;
Movie srcMovie;
Media dstMedia;
Track dstTrack;
long flags;
long numFrames;
SCTemporalSettings timeSettings;
Rect rect;
GWorldPtr imageWorld;
PixMapHandle pixMap;
ComponentInstance component;
BOOL copyAudio;
}

- (FrameData *)initWithMovieDataPtr:(MovieDataPtr)myData;
- (Media)dstMedia;
- (void)setDstMedia:(Media)newMedia;
- (ComponentInstance)component;
- (PixMapHandle)pixMap;
- (GWorldPtr)imageWorld;
- (Rect)rect;
- (Movie)srcMovie;
- (long)numFrames;
- (SCTemporalSettings)timeSettings;
- (long)flags;
- (void)setDstTrack:(Track)newDstTrack;
- (Track)dstTrack;
- (void)setDstMovie:(Movie)newMovie;
- (Movie)dstMovie;
- (short)refNum;
- (void)setRefNum:(short)newRefnum;
- (CGrafPtr)savedPort;
- (GDHandle)savedDevice;
- (TimeValue)origMovieTime;
- (long)numFrames;
- (BOOL)copyAudio;
@end
