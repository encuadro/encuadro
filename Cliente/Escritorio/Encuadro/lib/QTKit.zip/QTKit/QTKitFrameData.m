/*************************************************************************
|	QTKitFrameData.m
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
**************************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import "QTKitFrameData.h"

@implementation FrameData

- (TimeValue)origMovieTime
{
    return origMovieTime;
}

- (GDHandle)savedDevice
{
    return savedDevice;
}

- (CGrafPtr)savedPort
{
    return savedPort;
}

- (void)setRefNum:(short)newRefnum
{
    refNum = newRefnum;
}

- (short)refNum
{
    return refNum;
}

- (Movie)dstMovie
{
    return dstMovie;
}

- (void)setDstMovie:(Movie)newMovie
{
    dstMovie = newMovie;
}

- (Track)dstTrack
{
    return dstTrack;
}

- (void)setDstTrack:(Track)newDstTrack
{
    dstTrack = newDstTrack;
}

- (long)flags
{
    return flags;
}

- (SCTemporalSettings)timeSettings
{
    return timeSettings;
}

- (long)numFrames
{
    return numFrames;
}

- (Movie)srcMovie
{
    return srcMovie;
}

- (Rect)rect
{
    return rect;
}


- (GWorldPtr)imageWorld
{
    return imageWorld;
}

- (PixMapHandle)pixMap
{
    return pixMap;
}

- (ComponentInstance)component
{
    return component;
}

- (void)setDstMedia:(Media)newMedia
{
    dstMedia = newMedia;
}

- (Media)dstMedia
{
    return dstMedia;
}

- (FrameData *)initWithMovieDataPtr:(MovieDataPtr)myData
{
    rect = myData->myRect;
    srcMovie = myData->mySrcMovie;
    component = myData->myComponent;
    pixMap = myData->myPixMap;
    flags = myData->myFlags;
    imageWorld = myData->myImageWorld;
    numFrames = myData->myNumFrames;
    timeSettings = myData->myTimeSettings;
    savedPort = myData->mySavedPort;
    savedDevice = myData->mySavedDevice;
    copyAudio = myData->copyAudio;
    
    return self;
}

- (BOOL)copyAudio
{
    return copyAudio;
}

@end
