/*****************************************************************************************************************************************************
|	QTTestController.h
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
|	associated documentation files (the "Software"), to deal in the Software without restriction,
|	including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
|	 and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do
|	so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
|	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
|	FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
|	WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
****************************************************************************************************************************************************/

#import <Cocoa/Cocoa.h>

@class QTKitView;

@interface QTCompressController : NSObject
{
    IBOutlet NSWindow *aboutWindow;
    IBOutlet NSMenu *fileMenu;
    IBOutlet NSMenu *testMenu;
    IBOutlet QTKitView *movieView;
    IBOutlet NSMenuItem *openItem;
    IBOutlet NSMenuItem *closeItem;
    IBOutlet NSMenuItem *saveAsItem;
    IBOutlet NSMenuItem *saveItem;
    IBOutlet NSMenuItem *compressItem;
    IBOutlet NSPanel *progressPanel;
    IBOutlet NSProgressIndicator *progressBar;
    IBOutlet NSPanel *exportPanel;
    IBOutlet NSPopUpButton *exportMenu;
}
- (IBAction)doAbout:(id)sender;
- (IBAction)doCompress:(id)sender;
- (IBAction)doNew:(id)sender;
- (IBAction)doOpen:(id)sender;
- (IBAction)doSave:(id)sender;
- (IBAction)doSaveAs:(id)sender;
- (IBAction)pickExport:(id)sender;
- (NSPanel *)progressPanel;
- (NSPanel *)exportPanel;
- (NSProgressIndicator *)progressBar;
- (NSPopUpButton *)exportMenu;
@end
