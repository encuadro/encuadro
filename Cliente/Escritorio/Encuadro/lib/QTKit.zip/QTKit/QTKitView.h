/*******************************************************************
|	QTKitView.h
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
***********************************************************************/

/*********************************************************************
|	QTKitView want some help from you and Interface Builder. The
|	note at the top of QTKitUpdateBar.h tell you how to set up an
|	NSPanel with an NSProgressIndicator. There are additional things
|	you should do in Interface Builder. Drag an NSMovieView into a
|	Window and change it to an QTKitView. Then look in the header 
|	files of any of the Categories that you plan to use and see if
|	they require any user interface elements.
**********************************************************************/

/***********************************************************************
|	Much of this code came from Tim Monroe et. al. at Apple and was
|	cribbed from various sources including MacTech, the QuickTime
|	docs and Ice Floe. Cocoaization and way cool hacks are mine
|	while any bugs were in the original code from Apple -- Not!
*************************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import <Cocoa/Cocoa.h>
#import <QuickTime/QuickTime.h>
#import "QTKitUpdateBar.h"
#import "QTKitMovie.h"

@class QTKitMovie;

typedef struct _movieData {
    Rect		myRect;
    Movie		mySrcMovie;
    ComponentInstance	myComponent;
    PixMapHandle	myPixMap;
    long		myFlags;
    GWorldPtr		myImageWorld;
    long		myNumFrames;
    SCTemporalSettings	myTimeSettings;
    CGrafPtr		mySavedPort;
    GDHandle		mySavedDevice;
    BOOL		copyAudio;
} MovieData, *MovieDataPtr;

@interface QTKitView : NSMovieView <UpdateBar>
{
    GraphicsImportComponent	graphicsImporter;
    BOOL			isDirty;
    BOOL			isQTVRMovie;
    BOOL			eatingSpaces;
    QTVRInstance		instance;
    NSString			*FilePath;
    QTKitMovie			*myQTMovie;
}
- (void)openSourceURL;					// Opens the souce movie or image, 
                                                        // adjusting the window to keep it 
                                                        // proportional
- (void)setSourceMovie:(NSString *)fileName;		// Sets the source movie or image
                                                        // and the GraphicImporter
- (void)setWindowSizeForMovie;				// In the case your window only contains
                                                        // a movie, use this to scale and display it.
                                                        // Otherwise, you're on you own, but at least
                                                        // you have the source to help you
- (NSString *)filePath;
- (void)setFilePath:(NSString *)newPath;
- (void)setGraphicsImporter:(GraphicsImportComponent)gi;
- (GraphicsImportComponent)graphicsImporter;
- (BOOL)isImage;

// Since QT is not reentrant, and since the standard movie controller uses
// the spacebar as an on/off toggle, there are times when it is necessary 
// to intercept keydowns from the space bar. Set eatingSpaces to turn
// this on.
- (BOOL)eatingSpaces;
- (void)setEatingSpaces:(BOOL)amI;
- (FSSpec)makeFSSpecWithPath:(NSString *)path create:(BOOL)creatIt;
@end

// Utility functions
FSSpec nullFSSpec();

#define USE_CUSTOM_BUTTON 0