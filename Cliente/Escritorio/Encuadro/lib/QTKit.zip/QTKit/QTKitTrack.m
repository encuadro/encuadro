/*********************************************************************
|	Please read the comments in the header file
*********************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import "QTKitTrack.h"


@implementation QTKitTrack

-(id)initWithTrack:(Track) aTrack {
    self = [super init];
    QTTrack = aTrack;
    return self;
}

-(Track)QTTrack {
    return QTTrack;
}

-(BOOL)isAudio {
    OSType dwType;
    GetMediaHandlerDescription(GetTrackMedia(QTTrack), &dwType, nil, nil);
    if (dwType == SoundMediaType){
        return YES;
    } else {
        return NO;
    }
}

-(BOOL)isVideo {
    OSType dwType;
    GetMediaHandlerDescription([self media], &dwType, nil, nil);
    if (dwType == VideoMediaType){
        return YES;
    } else {
        return NO;
    }
}

-(BOOL)isText {
    OSType dwType;
    GetMediaHandlerDescription([self media], &dwType, nil, nil);
    if (dwType == TextMediaType){
        return YES;
    } else {
        return NO;
    }
}

-(OSType)TrackType {
    OSType dwType;
    GetMediaHandlerDescription(GetTrackMedia(QTTrack), &dwType, nil, nil);
    return dwType;
}

-(long)duration {
    return GetTrackDuration(QTTrack);
}

-(BOOL)isEnabled {
    return GetTrackEnabled(QTTrack);
}

-(void)setEnabled:(BOOL)ena {
    SetTrackEnabled(QTTrack, ena);
}

-(long)trackID {
    return GetTrackID(QTTrack);
}

-(Media)media {
    return GetTrackMedia(QTTrack);
}

-(short)volume {
    return GetTrackVolume(QTTrack);
}

-(void)setVolume:(short)aVolume {
    SetTrackVolume(QTTrack, aVolume);
}

-(void)setFullVolume {
    SetTrackVolume(QTTrack, kFullVolume);
}

-(void)setNoVolume {
    SetTrackVolume(QTTrack, kNoVolume);
}

@end
