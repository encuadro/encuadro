//
//  QTSlider.m
//  QTSlider
//
//  Created by Cyril Godefroy on Sun Feb 10 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import "QTKitSlider.h"

@implementation QTKitSlider

static Class cellClass;

+ (void) initialize {
  if (self == [QTKitSlider class])
    {
      // Initial version
      [self setVersion: 1];
      [self setCellClass: [QTKitSliderCell class]];
    }
}

+ (void) setCellClass: (Class)class {
  cellClass = class;
}

+ (Class) cellClass {
  return cellClass;
}

/*
- (void) mouseDown: (NSEvent *)theEvent
{
   [_cell drawWithFrame: _bounds inView: self];
      
      //[self trackKnob: theEvent knobRect: rect];
}
*/

@end
