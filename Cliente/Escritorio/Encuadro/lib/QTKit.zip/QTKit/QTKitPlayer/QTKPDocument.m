/**********************************************************************
|	QTKPDocument.m
|	Created by Cyril Godefroy on Mon Feb 25 2002.
|	Copyright (c) 2002 QTKit Project at Surceforge. 
|       All rights reserved.
***********************************************************************/

#import "QTKPDocument.h"

@implementation QTKPDocument

- (NSString *)windowNibName {
    return @"QTKPDocument";
}

- (void)windowControllerDidLoadNib:(NSWindowController *) aController {
    Rect tRect;
    float tMovieWidth,tMovieHeight;
    NSRect tFrame=[aMovieView frame];
    NSRect wFrame=[[aController window] frame];
    NSRect screenRect=[[NSScreen mainScreen] frame];
    
    [super windowControllerDidLoadNib:aController];
    if (aMovie != nil) {
        EnterMovies();
        aQTMovie = [aMovie QTMovie];
        tRect = [aMovie movieBox];
        tMovieWidth=tRect.right-tRect.left;
        tMovieHeight=tRect.bottom-tRect.top;
        wFrame.size.width=tMovieWidth+40;
        wFrame.size.height=tMovieHeight+140;
        wFrame.origin.y=screenRect.size.height-tMovieHeight-144;
        tFrame.size.width=tMovieWidth;
        tFrame.size.height=tMovieHeight;
        [[aController window] setFrame:wFrame display:YES];
        [[aController window] setAspectRatio:wFrame.size];
        [aMovieView setFrameSize:tFrame.size];

        [aMovieView showController:NO adjustingSize:NO];
        [aMovieView setMovie:aMovie];
        [self setMoviePropertyWindowControlValues];
        interfaceTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 
            target:self 
            selector:@selector(timerFire:) 
            userInfo:nil repeats:YES];
        [aVolumeSlider setFloatValue:[aMovieView volume]];
        [aTimeSlider setMaxValue:[aMovie duration]];
    }
}

-(void)close {
    [interfaceTimer invalidate];
    ExitMovies();
    [super close];
}

- (NSData *)dataRepresentationOfType:(NSString *)aType {
    return nil;
}

- (BOOL)loadDataRepresentation:(NSData *)data ofType:(NSString *)aType {
    return YES;
}

- (BOOL)readFromFile:(NSString *)fileName ofType:(NSString *)docType {
    NSURL *url = [[NSURL alloc] initFileURLWithPath:fileName];
    aMovie = [[QTKitMovie alloc] initWithURL:url byReference:YES];
    return YES;
}

- (void)goToBeginning:(id)sender {
    [self saveCurrentMoviePlayingState];
    [aMovieView gotoBeginning:sender];
    [self restoreMoviePlayingState:sender];
}

- (void)goToEnd:(id)sender {
    [aMovieView gotoEnd:sender];
}

- (IBAction)stepBack:(id)sender {
    [self saveCurrentMoviePlayingState];
    [aMovieView stepBack:sender];
    [self restoreMoviePlayingState:sender];
}

- (IBAction)stepForward:(id)sender {
    if ([aMovie isMovieDone]) {
        [aMovie goToBeginningOfMovie];
    }
    [self saveCurrentMoviePlayingState];
    [aMovieView stepForward:sender];
    [self restoreMoviePlayingState:sender];
}

- (void)Play:(id)sender {
    if ([aMovieView isPlaying]){
        [aMovieView stop:self];
    } else {
        [aMovieView setRate:1.0];
        [aMovieView start:self];
    }
}

- (void)Forward:(id)sender {
    if ([aMovieView rate]==1.0){
        [aMovieView setRate:2.0];
    } else {
        [aMovieView setRate:1.0];
    }
    if (![aMovieView isPlaying]){
        [aMovieView start:sender];
    }
}

- (void)Rewind:(id)sender {
    if ([aMovieView rate]==1.0){
        [aMovieView setRate:-1.0];
    } else {
        [aMovieView setRate:1.0];
    }
    if (![aMovieView isPlaying]){
        [aMovieView start:sender];
    }
}

- (void)saveCurrentMoviePlayingState {
    gIsMoviePlaying = [aMovieView isPlaying];
    gMoviePlaybackRate = [aMovieView rate];
}

- (void)restoreMoviePlayingState:(id)sender {
    if (gIsMoviePlaying) {
        [aMovieView start:sender];
    }
    [aMovieView setRate:gMoviePlaybackRate];
}

- (void)goFullScreen:(id)sender {
    /*
    int windowLevel;
    NSRect screenRect;
    
    windowLevel = CGShieldingWindowLevel();
    screenRect = [[NSScreen mainScreen] frame];
    fsWindow = [[[NSWindow alloc] retain] initWithContentRect:screenRect
                                styleMask:NSBorderlessWindowMask
                                backing:NSBackingStoreBuffered
                                defer:NO screen:[NSScreen mainScreen]];
                                
    fsMovieView = [[[LalaFSView alloc] retain] initWithFrame:screenRect withParent:self];
    [fsMovieView showController:NO adjustingSize:NO];
    [aMovieView setMovie:nil];
    [fsMovieView setMovie:aMovie];
    [NSCursor hide];
    [fsMovieView start:self];
    [fsWindow setContentView:fsMovieView];
    [fsWindow setBackgroundColor:[NSColor blackColor]];
    [fsWindow setLevel:windowLevel];
    [fsWindow makeKeyAndOrderFront:nil];
    */
}

- (void)stopFullScreen {
    /*
    [aMovieView setMovie:aMovie];
    [fsMovieView setMovie:nil];
    [fsMovieView removeFromSuperview];
    [fsMovieView release];
    [fsWindow orderOut:self];
    [fsWindow release];
    [NSCursor unhide];
    */
}

- (void)setMoviePropertyWindowControlValues {
    [aMovieTimeScale setStringValue:[aMovie timeScaleAsString]];
    [aMovieDuration setStringValue:[aMovie durationAsString]];
    [aMovieTime setStringValue:[aMovie timeAsString]];
}

- (IBAction)movieProperties:(id)sender {
    [self showTheWindow:moviePropertiesWindow];
}

- (void)showTheWindow:(NSWindow *)window {
    if (![window isVisible]) {
        [window setFrame:[window frame] display:YES];
    }
    [window makeKeyAndOrderFront:nil];
}

- (void)timerFire:(NSTimer *)timer {
    [aMovieTime setStringValue:[aMovie timeAsString]];
    [aTimeSlider setIntValue:[aMovie time]];
}

- (void)setVolume:(id)sender {
    [aMovieView setVolume:[sender floatValue]];
}

- (void)setTime:(id)sender {
    long int timevalue = [sender intValue];
    [aMovie setMovieTime:timevalue];
}

@end
