/**********************************************************************
|	QTKPApplication.m
|	Created by Cyril Godefroy on Mon Feb 25 2002.
|	Copyright (c) 2002 QTKit Project at Surceforge. 
|       All rights reserved.
***********************************************************************/

#import "QTKPApplication.h"

@implementation QTKPApplication

- (BOOL)applicationShouldOpenUntitledFile:(NSApplication *)sender {
    return NO;
}

@end