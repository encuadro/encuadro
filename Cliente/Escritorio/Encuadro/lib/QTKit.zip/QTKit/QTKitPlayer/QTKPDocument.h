/**********************************************************************
|	QTKPDocument.h
|	Created by Cyril Godefroy on Mon Feb 25 2002.
|	Copyright (c) 2002 QTKit Project at Surceforge. 
|       All rights reserved.
***********************************************************************/

/************************************************************************
|	This application is free software; you can redistribute it and/or
|	modify it under the terms of the GNU  General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This application is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	General Public License for more details.
*************************************************************************/

#import <Cocoa/Cocoa.h>
#import <QuickTime/Quicktime.h>
#import <QTKit/QTKit.h>

@interface QTKPDocument : NSDocument {
    IBOutlet QTKitView 	*aMovieView;
    QTKitMovie 		*aMovie;
    Movie		*aQTMovie;
    NSWindow 		*fsWindow;
    //LalaFSView 		*fsMovieView;
    BOOL 		gIsMoviePlaying;
    float 		gMoviePlaybackRate;
    NSTimer		*interfaceTimer;
    
    IBOutlet NSTextField *aMovieTimeScale;
    IBOutlet NSTextField *aMovieDuration;
    IBOutlet NSTextField *aMovieTime;
    IBOutlet NSWindow *moviePropertiesWindow;
    IBOutlet NSSlider *aVolumeSlider;
    IBOutlet NSSlider *aTimeSlider;
}

- (void)goToBeginning:(id)sender;
- (void)goToEnd:(id)sender;
- (IBAction)stepBack:(id)sender;
- (IBAction)stepForward:(id)sender;
- (void)Play:(id)sender;
- (void)Forward:(id)sender;
- (void)Rewind:(id)sender;
- (void)saveCurrentMoviePlayingState;
- (void)restoreMoviePlayingState:(id)sender;
- (void)goFullScreen:(id)sender;
- (void)stopFullScreen;
- (void)setMoviePropertyWindowControlValues;
- (IBAction)movieProperties:(id)sender;
- (void)showTheWindow:(NSWindow *)window;
- (void)timerFire:(NSTimer *)timer ;
- (void)setVolume:(id)sender;
- (void)setTime:(id)sender;

@end
