/*******************************************************************
|	QTKitTranscode.m
|	Created by Chris Gehlker on Fri Oct 12 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
***********************************************************************/

/*********************************************************************
|	Please read the comments in the header file
*********************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import "QTKitTranscode.h"
#import "QTTestController.h"
#import "QTKitFrameData.h"

static unsigned long exportType;
static GraphicsExportComponent expComponent;
static NSMutableDictionary *expCompDict;

@implementation QTKitView (Transcode)

- (void)transcodeMovie:(BOOL)withAudio;
{
    MovieDataPtr	myMovieData = malloc(sizeof(MovieData));
    Track		mySrcTrack = NULL;
    PicHandle		myPicture = NULL;
    ComponentResult	result;

    myMovieData->myComponent = NULL;
    myMovieData->mySrcMovie = [[self movie] QTMovie];
    myMovieData->myImageWorld = NULL;
    myMovieData->copyAudio = withAudio;

    // stop the movie
    [self stop:self];
    [self gotoBeginning:self];
    mySrcTrack = GetMovieIndTrackType(myMovieData->mySrcMovie, 1, VideoMediaType, movieTrackMediaType);
     
    // open an instance of the Standard Image Compression dialog component
    myMovieData->myComponent = OpenDefaultComponent(StandardCompressionType,
        StandardCompressionSubType);

    // turn off "best depth" option in the compression dialog, because all of our
    // buffering is done at 32-bits (regardless of the depth of the source data)
    // Also, we are recompressing a movie that may have a variable frame rate.
    // We want to allow the user to leave the frame rate text field blank (in which
    // case we can preserve the frame durations of the source movie); if the user
    // enters a number, we will resample the movie at a new frame rate; if we don't
    // set scAllowZeroFrameRate, the compression dialog will not allow a blank frame rate field

    SCGetInfo(myMovieData->myComponent, scPreferenceFlagsType, &myMovieData->myFlags);
    myMovieData->myFlags &= ~scShowBestDepth;
    myMovieData->myFlags |= scAllowZeroFrameRate;
    SCSetInfo(myMovieData->myComponent, scPreferenceFlagsType, &myMovieData->myFlags);

    // get the number of video frames in the movie
    myMovieData->myNumFrames = QT_GetFrameCount(mySrcTrack);

    // get the bounding rectangle of the movie, create a 32-bit GWorld with those
    // dimensions, and draw the movie poster picture into it; this GWorld will be
    // used for the test image in the compression dialog box and for rendering movie
    // frames
    myPicture = GetMoviePosterPict(myMovieData->mySrcMovie);
    GetMovieBox(myMovieData->mySrcMovie, &myMovieData->myRect);
    result = NewGWorld(&myMovieData->myImageWorld, 32, &myMovieData->myRect, NULL, NULL, 0L);
            
    // get the pixmap of the GWorld; we'll lock the pixmap, just to be safe
    myMovieData->myPixMap = GetGWorldPixMap(myMovieData->myImageWorld);

    // draw the movie poster image into the GWorld
    GetGWorld(&myMovieData->mySavedPort, &myMovieData->mySavedDevice);
    SetGWorld(myMovieData->myImageWorld, NULL);
    EraseRect(&myMovieData->myRect);
    DrawPicture(myPicture, &myMovieData->myRect);
    KillPicture(myPicture);
    SetGWorld(myMovieData->mySavedPort, myMovieData->mySavedDevice);

    // set the picture to be displayed in the dialog box
    SCSetTestImagePixMap(myMovieData->myComponent, myMovieData->myPixMap,
        NULL, scPreferScaling);

    // set up some default settings for the compression dialog
    SCDefaultPixMapSettings(myMovieData->myComponent, myMovieData->myPixMap, true);

    // clear out the default frame rate chosen by Standard Compression (a frame rate
    // of 0 means to use the rate of the source movie)
    result = SCGetInfo(myMovieData->myComponent, scTemporalSettingsType,
        &myMovieData->myTimeSettings);

    myMovieData->myTimeSettings.frameRate = 0;
    SCSetInfo(myMovieData->myComponent, scTemporalSettingsType, &myMovieData->myTimeSettings);

    // put up the dialog box
    result = SCRequestSequenceSettings(myMovieData->myComponent);
    if (result != noErr)
        return;

    // get a copy of the temporal settings the user entered
    SCGetInfo(myMovieData->myComponent, scTemporalSettingsType, &myMovieData->myTimeSettings);

    // if the user wants to resample the frame rate of the movie (as indicated a non-zero
    // value in the frame rate field) calculate the number of frames and duration for the new movie    
    if (myMovieData->myTimeSettings.frameRate != 0) {
            long	myDuration = GetMovieDuration(myMovieData->mySrcMovie);
            long	myTimeScale = GetMovieTimeScale(myMovieData->mySrcMovie);
            float	myFloat = (float)myDuration * myMovieData->myTimeSettings.frameRate;
            
            myMovieData->myNumFrames = myFloat / myTimeScale / 65536;
            if (myMovieData->myNumFrames == 0)
                    myMovieData->myNumFrames = 1;
    }

    // get the name and location of the new movie file
    [self QT_PutFileWithTitle:@"Save Movie" data:myMovieData];
}


// Set up the export menu for images
- (void)setUpExportMenu
{
    NSPanel *panel = [[[self window] delegate] exportPanel];
    NSPopUpButton *exportMenu = [[[self window] delegate] exportMenu];
    ComponentDescription cd, info;
    Component c = 0;
    OSErr err;
    OSType newComponent;
    NSString *descString = NULL;
    char nameBuffer[256];
    NSArray *compArray;
    int count, index;

    // if the menu exits, just show the panel
    if (expCompDict == NULL) {
	ComponentResult result;
	QTAtomContainer qtac;
	QTAtom theAtom;
	long actSize;
        NSNumber *theComp = 0;

        expCompDict = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
        
        cd.componentType = GraphicsExporterComponentType;
        cd.componentSubType = 0;
        cd.componentManufacturer = 0;
        cd.componentFlags = 0;
        cd.componentFlagsMask = graphicsExporterIsBaseExporter;
        
    // Loop through components, storing the subtype and name in a dictionary
        while( ( c = FindNextComponent(c, &cd ) ) != 0 ) {
            err = GetComponentInfo(c, &info, nil, nil, nil);
            newComponent = info.componentSubType;
            result = GraphicsExportGetMIMETypeList((ComponentInstance) c, &qtac);
            theAtom = QTFindChildByIndex(qtac, kParentAtomIsContainer,
                kMimeInfoDescriptionTag, 1, nil);
            err = QTCopyAtomDataToPtr(qtac, theAtom, YES, 256, nameBuffer, &actSize);
            nameBuffer[actSize] = 0;
            descString = [NSString stringWithCString:nameBuffer];
            theComp = [NSNumber numberWithUnsignedLong:newComponent];
            [expCompDict setObject:descString forKey:theComp];
        }
    
    // Clear out whatever was in the nib. Then alphabetize the menu so we can later find items
    // by thier index
    
        [exportMenu removeAllItems];
        compArray = [expCompDict keysSortedByValueUsingSelector:@selector(compare:)];
        count = [compArray count];
        for (index = 0; index < count; index++)
            [exportMenu addItemWithTitle:[expCompDict objectForKey:[compArray objectAtIndex:index]]];
    }
    [panel orderFront:self];
}

- (void)setExport
{
    NSPanel *panel = [[[self window] delegate] exportPanel];
    NSPopUpButton *exportMenu = [[[self window] delegate] exportMenu];
    NSArray *keyArray = [expCompDict keysSortedByValueUsingSelector:@selector(compare:)];
    int theItem;

    theItem = [exportMenu indexOfSelectedItem];
    exportType = [[keyArray objectAtIndex:theItem] unsignedLongValue];
    [panel orderOut:self];
    [self configExport];
}

- (void)configExport
{
    ComponentResult result;
    NSSavePanel *sp = [NSSavePanel savePanel];
    OSType fnExt;
    NSString *name = [NSString stringWithString:@"Untitled"];
    NSString *longName;
    char buffer[6];

    expComponent = OpenDefaultComponent(GraphicsExporterComponentType, exportType);
    result = CallComponentCanDo(expComponent, kGraphicsExportRequestSettingsSelect);
    if (result == YES)
        result = GraphicsExportRequestSettings(expComponent, nil, nil); 
    if (result == userCanceledErr)
        return;

    // get the file extension for the chosen exporter
    result = GraphicsExportGetDefaultFileNameExtension(expComponent, &fnExt);
    BlockMove(&fnExt, &buffer[1], 4);
    buffer[5] = 0;
    buffer[0] = '.';
    longName = [name stringByAppendingString:[NSString stringWithCString:buffer]];

    result = GraphicsExportSetInputGraphicsImporter(expComponent, [self graphicsImporter]);

    [sp beginSheetForDirectory:[NSHomeDirectory() stringByAppendingPathComponent:@"Pictures"]
        file:longName modalForWindow:[self window]
        modalDelegate:self didEndSelector:@selector(imageSavePanelDidEnd:returnCode:contextInfo:)
        contextInfo:nil];
}

- (void)imageSavePanelDidEnd:(NSSavePanel *)sheet returnCode:(int)returnCode
    contextInfo:(void *)contextInfo
{
    OSStatus	result = noErr;
    FSSpec	myFile;
    
    if (returnCode) {
        myFile = [self makeFSSpecWithPath:[sheet filename] create:YES];
        result = GraphicsExportSetOutputFile(expComponent, &myFile);
        result = GraphicsExportDoExport(expComponent, nil);
    }
    result = CloseComponent(expComponent);
    expComponent = NULL;
}

- (void)QT_PutFileWithTitle:(NSString*)title data:(void*)theData
{ 
     NSSavePanel *sp = [NSSavePanel savePanel];

    [sp setTitle:title];
    [sp beginSheetForDirectory:[NSHomeDirectory() stringByAppendingPathComponent:@"Movies"]
        file:@"Untitled.mov" modalForWindow:[self window]
        modalDelegate:self
        didEndSelector:@selector(movieSavePanelDidEnd:returnCode:contextInfo:)
        contextInfo:theData];
}

- (void)movieSavePanelDidEnd:(NSSavePanel *)sheet returnCode:(int)returnCode
    contextInfo:(void *)contextInfo
{
    MovieDataPtr	myData = contextInfo;
    Movie		myDstMovie = NULL;
    Track		myDstTrack = NULL;
    Media		myDstMedia = NULL;
    FSSpec		myFile;
    short		myRefNum = -1;
    MatrixRecord	myMatrix;
    OSErr		myErr = noErr;
    NSString		*theFile = [sheet filename];
    FrameData 		*myFrameData;

    if (!returnCode)
            goto bail;

    myFile = [self makeFSSpecWithPath:theFile create:YES];    
    myErr = CreateMovieFile(&myFile, sigMoviePlayer, smSystemScript,
        createMovieFileDeleteCurFile | createMovieFileDontCreateResFile, &myRefNum, &myDstMovie);
    if (myErr != noErr)
            goto bail;
    
    // create a new video movie track with the same dimensions as the entire source movie
    myDstTrack = NewMovieTrack(myDstMovie,
        (long)(myData->myRect.right - myData->myRect.left) << 16,
        (long)(myData->myRect.bottom - myData->myRect.top) << 16, kNoVolume);
    if (myDstTrack == NULL)
            goto bail;
    
    // create a media for the new track with the same time scale as the source movie;
    // because the time scales are the same, we don't have to do any time scale conversions.
    
        myDstMedia = NewTrackMedia(myDstTrack, VIDEO_TYPE,
        GetMovieTimeScale(myData->mySrcMovie), 0, 0);
    if (myDstMedia == NULL) {
            goto bail;
    }
    
    // copy the user data and settings from the source to the dest movie
    CopyMovieSettings(myData->mySrcMovie, myDstMovie);
    
    // set movie matrix to identity and clear the movie clip region (because the conversion
    // process transforms and composites all video tracks into one untransformed video track)
    SetIdentityMatrix(&myMatrix);
    SetMovieMatrix(myDstMovie, &myMatrix);
    SetMovieClipRgn(myDstMovie, NULL);
    
    // prepare for adding frames to the movie
    myFrameData = [[[FrameData alloc] initWithMovieDataPtr:myData] autorelease];
    [myFrameData setDstMedia:myDstMedia];
    [myFrameData setDstTrack:myDstTrack];
    [myFrameData setDstMovie:myDstMovie];
    [myFrameData setRefNum:myRefNum];
    [NSThread detachNewThreadSelector:@selector(loopThruFrames:)
        toTarget:self withObject:myFrameData];
    return;
bail:
    // close the Standard Compression component
    if (myData->myComponent != NULL)
            CloseComponent(myData->myComponent);

    if (myData->mySrcMovie != NULL) {
            // restore the source movie's original graphics port and device
            SetMovieGWorld(myData->mySrcMovie, myData->mySavedPort, myData->mySavedDevice);

            // restore the source movie's original movie time
    }
    
    // restore the original graphics port and device
    SetGWorld(myData->mySavedPort, myData->mySavedDevice);

    // delete the GWorld we were drawing frames into
    if (myData->myImageWorld != NULL)
            DisposeGWorld(myData->myImageWorld);
}


- (void)loopThruFrames:(FrameData *)myFrameData
{
    OSErr myErr;
    ImageDescriptionHandle myImageDesc = NULL;
    Rect myRect = [myFrameData rect];
    Movie mySrcMovie = [myFrameData srcMovie];
    TimeValue myCurMovieTime = 0L;
    long mySrcMovieDuration = 0L;
    short myFrameNum;
    long myFlags = [myFrameData flags];
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
    id theProxy;

    theProxy = [[NSConnection rootProxyForConnectionWithRegisteredName:@"UpdateBar" 
        host:nil] retain];
    [theProxy setProtocolForProxy:@protocol(UpdateBar)];
    myErr = BeginMediaEdits([myFrameData dstMedia]);
    if (myErr != noErr)
            goto bail;

    // we step through the source movie, compress each frame, and then add
    // the compressed frame to the destination movie
    [theProxy setBarMax:[myFrameData numFrames]];
    myErr = SCCompressSequenceBegin([myFrameData component], [myFrameData pixMap], NULL, &myImageDesc);
    if (myErr != noErr)
            goto bail;
    
    // clear out our image GWorld and set movie to draw into it
    SetGWorld([myFrameData imageWorld], NULL);
    EraseRect(&myRect);
    SetMovieGWorld(mySrcMovie, [myFrameData imageWorld],
        GetGWorldDevice([myFrameData imageWorld]));

    // set current time value to beginning of the source movie
    myCurMovieTime = 0;

    // get a value we'll need inside the loop
    mySrcMovieDuration = GetMovieDuration(mySrcMovie);

    // loop through all of the interesting times we counted above
    for (myFrameNum = 0; myFrameNum < [myFrameData numFrames]; myFrameNum++) {
        short			mySyncFlag;
        TimeValue		myDuration;
        long			myDataSize;
        Handle			myCompressedData;
        SCDataRateSettings	myRateSettings;

        // update the progress bar
        if (!(myFrameNum % 10))
            [theProxy setBarVal:myFrameNum];

        // if we are resampling the movie, step to the next frame
        if ([myFrameData timeSettings].frameRate) {
                myCurMovieTime = myFrameNum * mySrcMovieDuration / ([myFrameData numFrames] - 1);
                myDuration = mySrcMovieDuration / [myFrameData numFrames];
        } else {
                OSType		myMediaType = VIDEO_TYPE;
                myFlags = nextTimeMediaSample;

                // if this is the first frame, include the frame we are currently on		
                if (myFrameNum == 0)
                        myFlags |= nextTimeEdgeOK;
                
                // if we are maintaining the frame durations of the source movie,
                // skip to the next interesting time and get the duration for that frame
                GetMovieNextInterestingTime(mySrcMovie, myFlags,
                    1, &myMediaType, myCurMovieTime, 0, &myCurMovieTime, &myDuration);
            }
            
            SetMovieTimeValue(mySrcMovie, myCurMovieTime);
            MoviesTask(mySrcMovie, 0);
            MoviesTask(mySrcMovie, 0);
            MoviesTask(mySrcMovie, 0);

            // if data rate constraining is being done, tell Standard Compression the
            // duration of the current frame in milliseconds; we only need to do this
            // if the frames have variable durations
            if (!SCGetInfo([myFrameData component], scDataRateSettingsType, &myRateSettings)) {
                    myRateSettings.frameDuration = myDuration * 1000 /
                        GetMovieTimeScale(mySrcMovie);
                    SCSetInfo([myFrameData component], scDataRateSettingsType, &myRateSettings);
            }

            // if SCCompressSequenceFrame completes successfully, myCompressedData will hold
            // a handle to the newly-compressed image data and myDataSize will be the size of
            // the compressed data (which will usually be different from the size of the handle);
            // also mySyncFlag will be a value that that indicates whether or not the frame is a
            // key frame (and which we pass directly to AddMediaSample)
            myErr = SCCompressSequenceFrame([myFrameData component], [myFrameData pixMap],
                &myRect, &myCompressedData, &myDataSize, &mySyncFlag);
            if (myErr != noErr)
                    goto bail;

            myErr = AddMediaSample([myFrameData dstMedia], myCompressedData, 0, myDataSize,
                myDuration, (SampleDescriptionHandle)myImageDesc, 1, mySyncFlag, NULL);
            if (myErr != noErr)
                    goto bail;
    }
    
    // close the compression sequence; this will dispose of the image description
    // and compressed data handles allocated by SCCompressSequenceBegin
    SCCompressSequenceEnd([myFrameData component]);

    // add the media data to the destination movie
    myErr = EndMediaEdits([myFrameData dstMedia]);
    
    InsertMediaIntoTrack([myFrameData dstTrack], 0, 0, GetMediaDuration([myFrameData dstMedia]), fixed1);

    if ([myFrameData copyAudio])
        myErr = [self copyAudioTrackFromMovie:[myFrameData srcMovie] toMovie:[myFrameData dstMovie]];    
    myErr = AddMovieResource([myFrameData dstMovie], [myFrameData refNum], NULL, NULL);
bail:
    // close the Standard Compression component
    if ([myFrameData component] != NULL)
            CloseComponent([myFrameData component]);

    if ([myFrameData srcMovie] != NULL) {
            // restore the source movie's original graphics port and device
            SetMovieGWorld([myFrameData srcMovie], [myFrameData savedPort], [myFrameData savedDevice]);

            // restore the source movie's original movie time
            SetMovieTimeValue([myFrameData srcMovie], [myFrameData origMovieTime]);
    }
    
    // restore the original graphics port and device
    SetGWorld([myFrameData savedPort], [myFrameData savedDevice]);

    // delete the GWorld we were drawing frames into
    if ([myFrameData imageWorld] != NULL)
            DisposeGWorld([myFrameData imageWorld]);
    [theProxy hideBar];
    [self stepForward:self];
    [self gotoBeginning:self];
    [pool release];
}

- (void)compress
{
    if ([self isImage])
        [self setUpExportMenu];
    else
        [self transcodeMovie:YES];
}

- (OSErr)copyAudioTrackFromMovie:(Movie)srcMovie toMovie:(Movie)dstMovie
{
    OSErr err = noErr;
    Track src, dst;
    Media srcMedia, dstMedia;
    short count;
    Handle dataRef;
    OSType dataRefType;
    long dataRefattributes;
    TimeValue start, run;

    src = GetMovieIndTrackType(srcMovie, 1, AudioMediaCharacteristic,
        movieTrackEnabledOnly | movieTrackCharacteristic);
    if (src == NULL)
        return err;	// Movie had no Audio
    srcMedia = GetTrackMedia(src);    
    err = GetMediaDataRefCount(srcMedia, &count);
    if (count > 1)
        return MULTIPLEREFERROR;
    err = GetMediaDataRef(srcMedia, 1, &dataRef, &dataRefType, &dataRefattributes);
    err = AddEmptyTrackToMovie(src, dstMovie, dataRef, dataRefType, &dst);
    dstMedia = GetTrackMedia(dst);
    start = GetTrackOffset(src);
    run = GetTrackDuration(src);
    BeginMediaEdits(dstMedia);
    err = InsertTrackSegment(src, dst, start, run, start);
    EndMediaEdits(dstMedia);
    return err;
}
@end

long QT_GetFrameCount (Track theTrack)
{	
    long		myCount = -1;
    short		myFlags;
    TimeValue	myTime = 0;
	
    if (theTrack == NULL)
        goto bail;
		
    // we want to begin with the first frame (sample) in the track
    myFlags = nextTimeMediaSample + nextTimeEdgeOK;

    while (myTime >= 0) {
        myCount++;
		
        // look for the next frame in the track; when there are no more frames,
        // myTime is set to -1, so we'll exit the while loop
        GetTrackNextInterestingTime(theTrack, myFlags, myTime, fixed1, &myTime, NULL);
        
        // after the first interesting time, don't include the time we're currently at
        myFlags = nextTimeStep;
    }
    
    bail:
        return(myCount);
}