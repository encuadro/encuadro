/**********************************************************************
|	QTKitView.m
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
***********************************************************************/

/*********************************************************************
|	Please read the comments in the header file
*********************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import "QTKitView.h"
#import "QTTestController.h"
#import "QTKitTranscode.h"

const float borderWidth = 20.; // Based on UI guidelines in the nib

@implementation QTKitView

- (BOOL)isOpaque
{
    return YES;
}

- (void)openSourceURL {
    int result;
    NSMutableArray *fileTypes = [NSMutableArray arrayWithCapacity:100];
    NSOpenPanel *oPanel = [NSOpenPanel openPanel];

    [fileTypes addObjectsFromArray:[NSImage imageFileTypes]];
    [fileTypes addObjectsFromArray:[QTKitMovie movieUnfilteredFileTypes]];
    [fileTypes addObject:@"avi"];	//Apple forgot these.
    [fileTypes addObject:@"AVI"];
    result = [oPanel runModalForDirectory:[NSHomeDirectory() stringByAppendingPathComponent:@"Movies"]
        file:nil types:fileTypes];
    if (result == NSOKButton) {
        [self setFilePath:[oPanel filename]];
	[self setSourceMovie:[self filePath]];
        [self showController:(![self isImage]) adjustingSize:YES];
        [self display];
   }
}

- (void)setWindowSizeForMovie {
    NSSize windowSize;
    NSRect windowRect;
    NSWindow *theMovieWindow = [self window];
    NSRect bigRect = [[NSScreen mainScreen] visibleFrame];
    // make window proportional to movie
    windowSize = [self sizeForMagnification:1.0];
    windowSize.width += borderWidth * 2.;
    windowSize.height += borderWidth * 2.;
    // if it doesn't fit comfortably on the main screen, scale it down
    if (windowSize.width > bigRect.size.width -200) {
        float newWidth, newHeight;
        newWidth = bigRect.size.width -200;
        newHeight = windowSize.height * newWidth / windowSize.width;
        windowSize.width = newWidth;
        windowSize.height = newHeight;
    }
    if (windowSize.height > bigRect.size.height - 200) {
        float newWidth, newHeight;
        newHeight = bigRect.size.height - 200;
        newWidth = windowSize.width * newHeight / windowSize.height;
        windowSize.width = newWidth;
        windowSize.height = newHeight;
    }
    windowRect.origin.x = windowRect.origin.y = 100.;
    windowRect.size = windowSize;
    windowRect = [NSWindow frameRectForContentRect:windowRect
        styleMask:[theMovieWindow styleMask]];
    [theMovieWindow setFrame:windowRect display:NO];
    [theMovieWindow setTitleWithRepresentedFilename:[self filePath]];
    [theMovieWindow setAspectRatio:[theMovieWindow frame].size];
    [theMovieWindow makeKeyAndOrderFront:self];
}	

- (void)setSourceMovie:(NSString *)fileName
{
    // See if we got an image file
    FSSpec theSpec;
    OSErr err;
    GraphicsImportComponent GIC;

    theSpec = [self makeFSSpecWithPath:fileName create:NO];
    err = GetGraphicsImporterForFile(&theSpec, &GIC);
    [self setGraphicsImporter:GIC];
    myQTMovie = [[QTKitMovie alloc] initWithURL:[NSURL fileURLWithPath:fileName] byReference:YES];
    [self setMovie:myQTMovie];
}

- (NSString *)filePath {
    return FilePath;
}

- (void)setFilePath:(NSString *)newPath {
    [FilePath autorelease];
    FilePath = newPath;
    [FilePath retain];
}

- (void)setGraphicsImporter:(GraphicsImportComponent)gi {
    if ( (graphicsImporter != NULL) && (graphicsImporter != gi))
        CloseComponent(graphicsImporter);
    graphicsImporter = gi;
}

- (void)dealloc {
    [FilePath release];
    [myQTMovie release];
    if (graphicsImporter != NULL)
        CloseComponent(graphicsImporter);
    [super dealloc];
}

- (GraphicsImportComponent)graphicsImporter {
    return graphicsImporter;
}

- (BOOL)isImage {
    return graphicsImporter != NULL;
}

- (void)awakeFromNib {
    NSConnection *theConnection;
    
    theConnection = [NSConnection defaultConnection];
    [theConnection setRootObject:self];
    if ([theConnection registerName:@"UpdateBar"] == NO)
        NSLog(@"Couldn't vend connection");
}

- (void)setBarMax:(double)newMax; {
    NSPanel *myPanel = [[[self window] delegate] progressPanel];
    NSProgressIndicator *myBar = [[[self window] delegate] progressBar];
    [myPanel orderFront:self];
    [myBar setMaxValue:newMax];
    [self setEatingSpaces:YES];
    [self showController:NO adjustingSize:YES];
}

- (void)setBarVal:(double)newBarVal {
    [[[[self window] delegate] progressBar] setDoubleValue:newBarVal];
}

- (void)hideBar {
    [[[[self window] delegate] progressPanel] orderOut:self];
    [self setEatingSpaces:NO];
    [self showController:YES adjustingSize:YES];
}

- (void)setEatingSpaces:(BOOL)amI {
    eatingSpaces = amI;
}

- (void)keyDown:(NSEvent *)theEvent {
   if ([self eatingSpaces] && [[theEvent characters] isEqualToString:@" "])
        return;
    [super keyDown:theEvent];
}

- (BOOL)eatingSpaces {
    return eatingSpaces;
}

- (FSSpec)makeFSSpecWithPath:(NSString *)path create:(BOOL)creatIt {
    FSRef fsRef;
    FSSpec fsSpec;
    OSStatus err;
    NSFileManager *fm = [NSFileManager defaultManager];
    char bytes[4];
 
    if (![fm fileExistsAtPath:path])
        if (!creatIt)
            return nullFSSpec();
        else
            [fm createFileAtPath:path contents:[NSData dataWithBytes:bytes length:4] attributes:nil];

    err = FSPathMakeRef([path cString], &fsRef, NULL);
    if (err != noErr)
        return nullFSSpec();
    err = FSGetCatalogInfo(&fsRef, 0, NULL, NULL, &fsSpec, NULL);
    if (err != noErr)
        return nullFSSpec();
    return fsSpec;
}

@end

FSSpec nullFSSpec() {
    FSSpec temp;
    
    temp.vRefNum = temp.parID = temp.name[0] = NULL;
    return temp;
}
