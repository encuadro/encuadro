/**********************************************************************
|	QTKitTranscode.h
|	Created by Chris Gehlker on Fri Oct 12 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
***********************************************************************/

/************************************************************************
|	The QTKitTranscode category needs a little help from you in interface
|	Builder. Make the progress bar panel as outlined at the top of
|	QTKitUpdateBar.h. Then, if you  want to transcode any images, make
|	another panel and put an NSPopUpButton and a plain NSButton on it.
|	The NSButton should say "OK". The menus in the NSPopUpButton don't
|	matter because the setUpExportMenu method rebuilds them anyway based
|	on whatever GraphicsExporters are on the users machine. Make IBOutlets
|	to the NSPanel and the NSPopUpButton and define methods named exportPanel
|	and exportMenu respectively that return these IBOutlets. Then make a
|	method that sends the setExport message to the instance of QTKitView
|	and link an IBAction from the OK button to that method. This may sound
|	more complicated than it is. Look at QTTestController and its nib.
**************************************************************************/

/*******************************************************************************
|	Stuff To Do:
|
|	Enable compression at less than 32 bits and turn on "Best Depth" option
|	Enable copying of audio tracks into the new movie
|	Test for leaks
|	Add some error handling
|	Add option to copy sound tracks
|	Simplify the FrameData <-> MovieDataPointer interface
********************************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import <Foundation/Foundation.h>
#import "QTKitView.h"

// This is Picture Viewer. Change it to match your app.
#define kImageFileCreator FOUR_CHAR_CODE('ogle')
#define sigMoviePlayer FOUR_CHAR_CODE('TVOD')
#define MULTIPLEREFERROR -1
#define kFix1 0x00010000

@class FrameData;

@interface QTKitView (Transcode)
- (void)transcodeMovie:(BOOL)withAudio;
- (void)setUpExportMenu; // Sets up a menu of GraphicExportComponents
- (void)setExport;	// records the chosen Exporter

// Some GraphicsExportComponents support a configuration dialog. This method
// gives them a chance to run
- (void)configExport;
- (void)imageSavePanelDidEnd:(NSSavePanel *)sheet returnCode:(int)returnCode
    contextInfo:(void *)contextInfo;
- (void)QT_PutFileWithTitle:(NSString*)title data:(void*)theData; // launches "choose destination" sheet
- (void)movieSavePanelDidEnd:(NSSavePanel *)sheet returnCode:(int)returnCode
    contextInfo:(void *)contextInfo;
- (void)loopThruFrames:(FrameData *)myFrameData;  // The real work of compression is done here
- (void)compress;	// Dispaches between movie and image transcoders
- (OSErr)copyAudioTrackFromMovie:(Movie)srcMovie toMovie:(Movie)dstMovie;
@end

long QT_GetFrameCount(Track theTrack);