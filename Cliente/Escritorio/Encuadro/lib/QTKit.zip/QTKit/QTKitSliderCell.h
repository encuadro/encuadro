//
//  QTSliderCell.h
//  QTSlider
//
//  Created by Cyril Godefroy on Sun Feb 10 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <AppKit/NSSliderCell.h>

@class NSString;
@class NSColor;
@class NSFont;
@class NSImage;

@interface QTKitSliderCell : NSSliderCell {
    id		_leftKnobCell;
    id		_rightKnobCell;
}
@end
