/*********************************************************************
|	Please read the comments in the header file
*********************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import "QTKitMovie.h"

static StringPtr MakeMovieTimeDisplayString(long	movieTotalSeconds);

@implementation QTKitMovie

- (void)setMovieTime:(long)time {
    long int timeValue = time;
    SetMovieTimeValue([self QTMovie], timeValue);
    MoviesTask([self QTMovie], 0);
}

- (long)time {
    return GetMovieTime([self QTMovie], nil);
}

- (long)timeAsSec {
    return GetMovieTime([self QTMovie], nil)/[self timeScale];
}

- (NSString*)timeAsString {
    return (@"No time yet");
}

- (long)duration {
    return GetMovieDuration([self QTMovie]);
}

- (NSString*)durationAsString {
    StringPtr	movieDurationString = MakeMovieTimeDisplayString([self duration]);

    NSString	*movieDurationNSString = [NSString stringWithCString:movieDurationString];
    DisposePtr((Ptr)movieDurationString);
    
    return movieDurationNSString;
}

- (void)setTimeScale:(long)timeScale {
    
}

- (long)timeScale {
    return GetMovieTimeScale([self QTMovie]);
}

- (NSString*)timeScaleAsString {
    NSString *timeScaleNSString;
    long ts;
    StringPtr timeScaleString;
    ts = [self timeScale];
    timeScaleString = NewPtr(sizeof(Str255));
    timeScaleString[0] = 0;
    NumToString(ts, timeScaleString);
    p2cstrcpy(timeScaleString, (ConstStr255Param)timeScaleString);
    timeScaleNSString = [NSString stringWithCString:timeScaleString];
    DisposePtr((Ptr)timeScaleString);
    return timeScaleNSString;
}

- (Rect)movieBox {
    Rect tRect;
    GetMovieBox([self QTMovie],&tRect);
    return tRect;
}

/*****************/
/* Tracks stuff  */
/*****************/

-(void)checkQTMovieTracks {
    QTKitTrack *aQTTrack;
    int i;
    
    QTMovieTracks = [[NSMutableArray alloc] init];
    for ( i=1; i <= GetMovieTrackCount([self QTMovie]); i++) {
        aQTTrack = [[QTKitTrack alloc] initWithTrack:GetMovieIndTrack([self QTMovie], i)];
        [QTMovieTracks addObject:aQTTrack];
    }
}

- (int)trackCount {
    return [QTMovieTracks count];
}

- (QTKitTrack*)trackAtIndex:(int)track {
    return [QTMovieTracks objectAtIndex:track];
}

- (BOOL)isMovieDone {
    return IsMovieDone([self QTMovie]);
}

- (void)goToBeginningOfMovie {
    GoToBeginningOfMovie([self QTMovie]);
}

@end

static StringPtr MakeMovieTimeDisplayString(long movieTotalSeconds) {
    Str255 tempString;
    StringPtr finalString;

    long movieHours;
    long movieMinutes;
    long movieSeconds;

    finalString = NewPtr(sizeof(Str255));
    finalString[0] = 0;
    
    /* This is the readout that says something like: �2 minutes 5 seconds� */
	
    movieHours = movieTotalSeconds / (60 * 60);
    movieMinutes = movieTotalSeconds / 60;
    movieSeconds = movieTotalSeconds % 60;
    	
    tempString[0] = 0;
	
    if (movieHours != 0){			
        if (movieHours < 10) {
            PLstrcat(finalString, "\p0");
        }
        NumToString(movieHours, tempString);
        PLstrcat(finalString, (ConstStr255Param)&tempString);
    } else {
        PLstrcat(finalString,"\p00");
    }
    
    PLstrcat(finalString,"\p:");
    tempString[0] = 0;
	
    if (movieMinutes != 0) {			
        if (movieMinutes < 10) {
            PLstrcat(finalString, "\p0");
        }
        NumToString(movieMinutes, tempString);
        PLstrcat(finalString, (ConstStr255Param)&tempString);
    } else {
        PLstrcat(finalString,"\p00");
    }
    
    PLstrcat(finalString,"\p:");
    tempString[0] = 0;

    if (movieSeconds != 0) {
        if (movieSeconds < 10) {
            PLstrcat(finalString, "\p0");
        }
        NumToString(movieSeconds, tempString);
        PLstrcat(finalString, (ConstStr255Param)&tempString);
    } else {
        PLstrcat(finalString,"\p00");
    }

    /* Now, if the movie is shorter than one second long (�zero seconds�), but
    _not_ zero duration, handle that case specially. */

    if ((movieMinutes == 0) && (movieSeconds == 0) && (movieHours == 0) && (movieTotalSeconds != 0)){
        finalString[0] = 0;
        PLstrcat(finalString,"< O s");
    }

    p2cstrcpy(finalString, (ConstStr255Param)finalString);
    return finalString;
}


