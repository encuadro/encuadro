//
//  QTSliderCell.m
//  QTSlider
//
//  Created by Cyril Godefroy on Sun Feb 10 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import "QTKitSliderCell.h"

#import <Foundation/NSString.h>

#import <AppKit/NSColor.h>
#import <AppKit/NSControl.h>
#import <AppKit/NSImage.h>
#import <AppKit/NSTextFieldCell.h>

@implementation QTKitSliderCell

- (id) init {
    self = [super init];
    _leftKnobCell = [NSCell new];
    _rightKnobCell = [NSCell new];
    return self;
}

- (void) dealloc
{
  [_leftKnobCell release];
  [_rightKnobCell release];
  [super dealloc];
}

- (void) drawKnob:(NSRect) knobRect {
    NSImage	*image;
    image = [[NSImage alloc] 
        initWithContentsOfFile:[[NSBundle bundleForClass:[self class]] 
        pathForResource:@"tracker2" 
        ofType:@"tiff"]];
    [image compositeToPoint:NSMakePoint(knobRect.origin.x+5,knobRect.origin.y+15) 
        operation:NSCompositeSourceOver];
}

- (void) drawBarInside: (NSRect)rect flipped: (BOOL)flipped {
    [[NSColor scrollBarColor] set];
    NSDrawWindowBackground(rect);
    rect.origin.x = rect.origin.x+10;
    rect.origin.y = rect.origin.y+6;
    rect.size.width = rect.size.width-15;
    rect.size.height = rect.size.height-12;                       
    NSFrameRect(rect);
    NSRectFill(rect);
}

- (void) drawInteriorWithFrame: (NSRect)cellFrame inView: (NSView*)controlView {
    cellFrame = [self drawingRectForBounds: cellFrame];
    [controlView lockFocus];
    //_trackRect = cellFrame;
    [self drawBarInside: cellFrame flipped: [controlView isFlipped]];
    [self drawKnob];
    [controlView unlockFocus];
}

@end
