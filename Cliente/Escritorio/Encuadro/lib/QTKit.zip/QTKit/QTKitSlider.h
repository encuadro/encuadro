//
//  QTSlider.h
//  QTSlider
//
//  Created by Cyril Godefroy on Sun Feb 10 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <AppKit/NSControl.h>
#import <AppKit/NSSlider.h>
#import <QTKitSliderCell.h>

@interface QTKitSlider : NSSlider

@end
