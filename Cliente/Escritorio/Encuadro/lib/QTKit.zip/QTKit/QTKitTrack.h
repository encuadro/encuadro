/**********************************************************************
|	QTKitTrack.m
|	Created by Cyril Godefroy on Sun Feb 03 2002.
|	Copyright (c) 2001 QTKit Project at Sourceforge. 
|       All rights reserved.
***********************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

#import <Foundation/Foundation.h>
#import <QuickTime/Quicktime.h>

@interface QTKitTrack : NSObject {
    Track	QTTrack;
}

-(id)initWithTrack:(Track) aTrack;
-(Track)QTTrack;
-(BOOL)isAudio;
-(BOOL)isVideo;
-(BOOL)isText;
-(OSType)TrackType;
-(long)duration;
-(BOOL)isEnabled;
-(void)setEnabled:(BOOL)ena;
-(long)trackID;
-(Media)media;
-(short)volume;
-(void)setVolume:(short)aVolume;
-(void)setFullVolume;
-(void)setNoVolume;

@end
