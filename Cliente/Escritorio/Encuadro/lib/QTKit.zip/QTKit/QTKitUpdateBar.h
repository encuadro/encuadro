/*******************************************************************
|	QTKitUpDateBar.h
|	Created by Chris Gehlker on Sat Oct 20 2001.
|	Copyright (c) 2001 Grand Canyon Code Factory. All rights reserved.
***********************************************************************/

/************************************************************************
|	This protocol is implemented by QTKitView. It show a progress bar
|	during lengthly operations. Applications using QTKitView should
|	provide a determinate NSProgressIndicator inside an NSPanel. The
|	NSPanel should be invisible at launch time. The application should
|	define IBOutlets to the panel and the progress indicator and return
|	those outlets in the progressPanel and progressBar methods respectively.
|
|	QTKitView spawns a new tread for transcoding movies and uses the
|	progress bar to let the user know it's still crunching away.
*************************************************************************/

/************************************************************************
|	This library is free software; you can redistribute it and/or
|	modify it under the terms of the GNU Lesser General Public
|	License as published by the Free Software Foundation; either
|	version 2.1 of the License, or (at your option) any later version.
|
|	This library is distributed in the hope that it will be useful,
|	but WITHOUT ANY WARRANTY; without even the implied warranty of
|	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
|	Lesser General Public License for more details.
*************************************************************************/

@protocol UpdateBar
- (void)setBarMax:(double)newMax;
- (void)setBarVal:(double)newBarVal;
- (void)hideBar;
@end