//
//  Composit.h
//  CoplanarPosit
//
//  Created by Juan Ignacio Braun on 3/16/12.
//  Copyright (c) 2012 juanibraun@gmail.com. All rights reserved.
//


#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void Composit(long int np,double** coplImage,double** copl, double fLength, double** R, double* T);