//
//  casoUso0200main.h
//  casoUso0200
//
//  Created by encuadro augmented reality on 9/15/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	UIApplicationMain(argc, argv, nil, @"casoUso0200AppDelegate");
	[pool release];
	return 0;
}
