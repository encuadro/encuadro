//
//  configuration.h
//  demo05
//
//  Created by Pablo Flores Guridi on 23/08/12.
//  Copyright (c) 2012 pablofloresguridi@gmail.com. All rights reserved.
//

#ifndef demo05_configuration_h
#define demo05_configuration_h

extern bool verbose;

#endif
